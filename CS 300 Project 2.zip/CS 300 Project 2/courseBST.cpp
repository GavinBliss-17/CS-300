#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>

using namespace std;

class Course {
public:
    string courseNumber;
    string title;
    vector<string> prereqs;

    Course(string number, string name, vector<string> prerequisites) : courseNumber(number), title(name), prereqs(prerequisites) {}
};

class BSTNode {
public:
    Course course;
    BSTNode* left;
    BSTNode* right;

    BSTNode(Course c) : course(c), left(nullptr), right(nullptr) {}
};

class CourseBST {
private:
    BSTNode* root;

    BSTNode* insert(BSTNode* node, Course course) {
        if (!node) return new BSTNode(course);
        if (course.courseNumber < node->course.courseNumber) {
            node->left = insert(node->left, course);
        } else if (course.courseNumber > node->course.courseNumber) {
            node->right = insert(node->right, course);
        }
        return node;
    }

    void inOrderTraversal(BSTNode* node) {
        if (!node) return;
        inOrderTraversal(node->left);
        cout << node->course.courseNumber << " - " << node->course.title << endl;
        inOrderTraversal(node->right);
    }

    void printCourseInfo(BSTNode* node, const string& courseNumber) {
        if (!node) return;
        if (courseNumber == node->course.courseNumber) {
            cout << "Course Number: " << node->course.courseNumber << endl;
            cout << "Title: " << node->course.title << endl;
            if (!node->course.prereqs.empty()) {
                cout << "Prerequisites: ";
                for (const auto& prereq : node->course.prereqs) {
                    cout << prereq << " ";
                }
                cout << endl;
            } else {
                cout << "There are no prerequisites for this course." << endl;
            }
        } else if (courseNumber < node->course.courseNumber) {
            printCourseInfo(node->left, courseNumber);
        } else {
            printCourseInfo(node->right, courseNumber);
        }
    }

public:
    CourseBST() : root(nullptr) {}

    void insert(Course course) {
        root = insert(root, course);
    }

    void printAllCourses() {
        inOrderTraversal(root);
    }

    void findAndPrintCourse(const string& courseNumber) {
        printCourseInfo(root, courseNumber);
    }
};

void loadCoursesFromFile(const string& filename, CourseBST& bst) {
    ifstream file(filename);
    string line;

    if (!file) {
        cerr << "Unable to open file: " << filename << endl;
        return;
    }

    while (getline(file, line)) {
        stringstream ss(line);
        string courseNumber, title, token;
        vector<string> prereqs;

        getline(ss, courseNumber, ',');
        getline(ss, title, ',');

        while (getline(ss, token, ',')) {
            prereqs.push_back(token);
        }

        Course course(courseNumber, title, prereqs);
        bst.insert(course);
    }

    file.close();
    cout << "Data loaded successfully." << endl;
}

void displayMenu() {
    cout << "=== Main Menu ===" << endl;
    cout << "1. Load Data Structure" << endl;
    cout << "2. Print Course List" << endl;
    cout << "3. Print Course" << endl;
    cout << "4. Exit" << endl;
}

void handleUserInput(CourseBST& bst) {
    bool dataLoaded = false;
    string choice;

    while (true) {
        displayMenu();
        cout << "Choose an option: ";
        cin >> choice;

        if (choice == "1") {
            string filePath;
            cout << "Enter the file path: ";
            cin >> filePath;
            loadCoursesFromFile(filePath, bst);
            dataLoaded = true;
        } else if (choice == "2") {
            if (!dataLoaded) {
                cout << "Please load the data structure first." << endl;
            } else {
                bst.printAllCourses();
            }
        } else if (choice == "3") {
            if (!dataLoaded) {
                cout << "Please load the data structure first." << endl;
            } else {
                string courseNumber;
                cout << "Enter the course number: ";
                cin >> courseNumber;
                bst.findAndPrintCourse(courseNumber);
            }
        } else if (choice == "4") {
            cout << "Exiting program..." << endl;
            break;
        } else {
            cout << "Invalid option, please try again." << endl;
        }
    }
}

int main() {
    CourseBST bst;
    cout << "ABCU Advising Program" << endl;
    handleUserInput(bst);
    return 0;
}
